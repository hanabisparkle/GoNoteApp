package com.example.gonoteapp.fragments

import android.graphics.Canvas
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.gonoteapp.FolderAdapter
import com.example.gonoteapp.MainActivity
import com.example.gonoteapp.NoteRepository
import com.example.gonoteapp.OnFolderClickListener
import com.example.gonoteapp.R
import com.example.gonoteapp.model.Folder
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class FolderListFragment : Fragment(), OnFolderClickListener, NoteRepository.OnDataChangeListener {
    private lateinit var foldersRecyclerView: RecyclerView
    private lateinit var foldersAdapter: FolderAdapter
    private lateinit var deleteButton: Button
    private lateinit var selectAllCheckbox: CheckBox
    private lateinit var emptyView: TextView
    private var isSelectionMode = false
    private val selectedFolders = mutableSetOf<Folder>()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        foldersRecyclerView = view.findViewById(R.id.folders_recycler_view)
        emptyView = view.findViewById(R.id.folder_empty_view)
        foldersAdapter = FolderAdapter(this)
        setupRecyclerView()

        val selectButton: Button = view.findViewById(R.id.folder_select_button)
        deleteButton = view.findViewById(R.id.folder_delete_button)
        selectAllCheckbox = view.findViewById(R.id.select_all_checkbox)

        selectButton.setOnClickListener {
            isSelectionMode = !isSelectionMode
            foldersAdapter.setSelectionMode(isSelectionMode)
            if (isSelectionMode) {
                deleteButton.visibility = View.VISIBLE
                selectAllCheckbox.visibility = View.VISIBLE
            } else {
                deleteButton.visibility = View.GONE
                selectAllCheckbox.visibility = View.GONE
                selectAllCheckbox.isChecked = false
                selectedFolders.clear()
            }
        }

        selectAllCheckbox.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                foldersAdapter.selectAll()
            } else {
                foldersAdapter.deselectAll()
            }
        }

        deleteButton.setOnClickListener {
            if (selectedFolders.isNotEmpty()) {
                showDeleteSelectedFoldersDialog(selectedFolders)
            }
        }

        val itemTouchHelperCallback = object : ItemTouchHelper.SimpleCallback(0,
            ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT) {

            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ) : Boolean {
                return false
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val position = viewHolder.adapterPosition
                val folder = foldersAdapter.getFolderAt(position)

                if (direction == ItemTouchHelper.LEFT) {
                    showDeleteFolderConfirmationDialog(folder, viewHolder)
                } else {
                    showEditFolderDialog(folder)
                    foldersAdapter.notifyItemChanged(position)
                }
            }
            override fun onChildDraw(
                c: Canvas,
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                dX: Float,
                dY: Float,
                actionState: Int,
                isCurrentlyActive: Boolean
            ) {
                val foregroundView = viewHolder.itemView.findViewById<View>(R.id.card_view_folder)
                val editLayout = viewHolder.itemView.findViewById<View>(R.id.edit_action_layout_folder)
                val deleteLayout = viewHolder.itemView.findViewById<View>(R.id.delete_action_layout_folder)

                if (dX > 0) {
                    editLayout.visibility = View.VISIBLE
                    deleteLayout.visibility = View.GONE
                } else if (dX < 0) {
                    editLayout.visibility = View.GONE
                    deleteLayout.visibility = View.VISIBLE
                } else {
                    editLayout.visibility = View.GONE
                    deleteLayout.visibility = View.GONE
                }

                ItemTouchHelper.Callback.getDefaultUIUtil().onDraw(c, recyclerView, foregroundView, dX, dY, actionState, isCurrentlyActive)
            }

            override fun clearView(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder) {
                val foregroundView = viewHolder.itemView.findViewById<View>(R.id.card_view_folder)
                val editLayout = viewHolder.itemView.findViewById<View>(R.id.edit_action_layout_folder)
                val deleteLayout = viewHolder.itemView.findViewById<View>(R.id.delete_action_layout_folder)

                editLayout.visibility = View.GONE
                deleteLayout.visibility = View.GONE

                ItemTouchHelper.Callback.getDefaultUIUtil().clearView(foregroundView)
            }
        }
        ItemTouchHelper(itemTouchHelperCallback).attachToRecyclerView(foldersRecyclerView)
    }

    override fun onDestroyView() {
        super.onDestroyView()
    }

    override fun onDataChanged() {
        loadFolders()
    }

    override fun onResume() {
        super.onResume()
        (activity as? MainActivity)?.updateTitle("Folders")
        loadFolders()
    }

    private fun showEditFolderDialog(folder: Folder) {
        val context = requireContext()
        val editText = EditText(context).apply {
            setText(folder.name)
        }

        MaterialAlertDialogBuilder(context)
            .setTitle("Edit Folder Name")
            .setView(editText)
            .setPositiveButton("Save") { _, _ ->
                val newName = editText.text.toString()
                if (newName.isNotBlank() && newName != folder.name) {
                    NoteRepository.updateFolder(folder.id, newName)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showDeleteFolderConfirmationDialog(folder: Folder, viewHolder: RecyclerView.ViewHolder) {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Delete Folder")
            .setMessage("Are you sure you want to delete '${folder.name}'? Notes inside will become uncategorized.")
            .setPositiveButton("Delete") { _, _ ->
                NoteRepository.deleteFolder(folder.id)
                loadFolders()
            }
            .setNegativeButton("Cancel") { _, _ ->
                foldersAdapter.notifyItemChanged(viewHolder.adapterPosition)
            }
            .setOnCancelListener {
                foldersAdapter.notifyItemChanged(viewHolder.adapterPosition)
            }
            .show()
    }

    private fun showDeleteSelectedFoldersDialog(selectedFolders: Set<Folder>){
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Delete Selected Folders")
            .setMessage("Are you sure you want to permanently delete the selected folders? Any notes within them will be uncategorized.")
            .setPositiveButton("Delete") { _, _ ->
                for (folder in selectedFolders) {
                    var currentFolderNotes = NoteRepository.getNotesForFolder(folder.id)
                    if (currentFolderNotes.isNotEmpty()) {
                        for (note in currentFolderNotes) {
                            note.folderId = 0L
                        }
                    }
                    NoteRepository.deleteFolder(folder.id)
                }
                loadFolders()
            }
            .setNegativeButton("Cancel", null)
            .create()
            .show()
    }

    private fun setupRecyclerView() {
        foldersRecyclerView.adapter = foldersAdapter
        foldersRecyclerView.layoutManager = LinearLayoutManager(requireContext())
    }

    private fun loadFolders() {
        val folders = NoteRepository.getAllFolders()
        foldersAdapter.setData(folders)
        if (folders.isEmpty()) {
            foldersRecyclerView.visibility = View.GONE
            emptyView.visibility = View.VISIBLE
        } else {
            foldersRecyclerView.visibility = View.VISIBLE
            emptyView.visibility = View.GONE
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_folder_list, container, false)
    }

    override fun onFolderClicked(folder: Folder) {
        (activity as? MainActivity)?.onFolderSelected(folder.name)
        val fragment = FolderNotesFragment.newInstance(folder.id)
        parentFragmentManager.beginTransaction()
            .replace(R.id.my_fragment_container, fragment)
            .addToBackStack(null)
            .commit()
    }

    override fun onFolderSelected(folder: Folder, isSelected: Boolean) {
        if (isSelected) {
            selectedFolders.add(folder)
        } else {
            selectedFolders.remove(folder)
        }
    }

    fun showNewFolderDialog() {
        val editText = EditText(requireContext()).apply {
            hint = "Folder Name"
        }

        val layout = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(60, 40, 60, 20)
            addView(editText)
        }

        MaterialAlertDialogBuilder(requireContext())
            .setTitle("New Folder")
            .setView(layout)
            .setPositiveButton("Create") { _, _ ->
                val folderName = editText.text.toString()
                if (folderName.isNotBlank()) {
                    NoteRepository.addFolder(folderName)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
