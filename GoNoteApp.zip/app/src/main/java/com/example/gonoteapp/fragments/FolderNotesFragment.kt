package com.example.gonoteapp.fragments

import android.os.Bundle
import android.view.View
import androidx.appcompat.widget.Toolbar
import com.example.gonoteapp.MainActivity
import com.example.gonoteapp.NoteRepository
import com.example.gonoteapp.NoteRepository.getFolderById
import com.example.gonoteapp.R
import kotlin.properties.Delegates

class FolderNotesFragment : BaseNoteListFragment() {

    private lateinit var folderName: String
    private var folderId by Delegates.notNull<Long>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            folderId = it.getLong(ARG_FOLDER_ID)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        folderName = getFolderById(folderId)?.name ?: "Unknown Folder"
        (activity as? MainActivity)?.updateTitle(folderName)

        val toolbar = activity?.findViewById<Toolbar>(R.id.toolbar)
        toolbar?.setNavigationIcon(R.drawable.ic_back)
        toolbar?.setNavigationOnClickListener {
            parentFragmentManager.popBackStack()
        }
    }

    override fun onResume() {
        super.onResume()
        // When we resume this fragment, ensure the title is set correctly.
        (activity as? MainActivity)?.updateTitle(folderName)
        loadNotes()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        val toolbar = activity?.findViewById<Toolbar>(R.id.toolbar)
        toolbar?.navigationIcon = null
        toolbar?.setNavigationOnClickListener(null)
    }

    override fun loadNotes() {
        // The implementation for this screen is to load notes for a specific folder
        val notes = NoteRepository.getNotesForFolder(folderId)
        noteAdapter.setData(notes)
        updateEmptyViewVisibility(notes, R.string.empty_notes)
    }

    companion object {
        private const val ARG_FOLDER_ID = "folder_id"
        fun newInstance(folderId: Long): FolderNotesFragment {
            val fragment = FolderNotesFragment()
            val args = Bundle()
            args.putLong(ARG_FOLDER_ID, folderId)
            fragment.arguments = args
            return fragment
        }
    }
}
