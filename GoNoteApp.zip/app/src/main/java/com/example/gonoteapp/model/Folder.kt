package com.example.gonoteapp.model

data class Folder(
    val id: Long,
    var name: String,
    var noteCount:  Int = 0
)
